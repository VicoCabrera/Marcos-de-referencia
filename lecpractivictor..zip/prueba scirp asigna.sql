Drop database if exists edu_tecdb;
CREATE DATABASE IF NOT EXISTS edu_tecdb;
USE edu_tecdb;

-- Tabla de Instituciones de Educación Superior (IES)
CREATE TABLE ies (
  ies_id int(11) NOT NULL AUTO_INCREMENT,
  codigo_sniese varchar(20) NOT NULL,
  nombre_institucion varchar(200) NOT NULL,
  PRIMARY KEY (ies_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabla de Carreras
CREATE TABLE carrera (
  codigo_carrera varchar(20) NOT NULL,
  nombre_carrera varchar(200) NOT NULL,
  nivel varchar(50) NOT NULL,
  modalidad varchar(50) NOT NULL,
  jornada varchar(50) NOT NULL,
  area varchar(100) NOT NULL,
  subarea varchar(100) NOT NULL,
  grupo_asignacion varchar(50) NOT NULL,
  politica_cuotas varchar(100) NOT NULL,
  PRIMARY KEY (codigo_carrera)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabla de Postulantes
CREATE TABLE postulante (
  cedula varchar(15) NOT NULL,
  tipo_documento varchar(50) NOT NULL,
  apellidos varchar(100) NOT NULL,
  nombres varchar(100) NOT NULL,
  nota_postula decimal(5,2) NOT NULL,
  fecha_nac date NOT NULL,
  nacionalidad varchar(50) NOT NULL,
  genero varchar(50) NOT NULL,
  provincia_reside varchar(100) NOT NULL,
  canton_reside varchar(100) NOT NULL,
  parroquia_reside varchar(100) NOT NULL,
  email varchar(100) default NULL,
  telefono varchar(20) NOT NULL,
  celular varchar(20) NOT NULL,
  etnia varchar(50) NOT NULL,
  discapacidad varchar(50) NOT NULL,
  PRIMARY KEY (cedula)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabla de Postulación
CREATE TABLE postulacion (
  id_postulacion int(11) NOT NULL AUTO_INCREMENT,
  cedula varchar(15) NOT NULL,
  codigo_carrera varchar(20) DEFAULT NULL,
  instancia_postulacion varchar(100) NOT NULL,
  instancia_asignacion varchar(100) NOT NULL,
  fecha_aceptacion date NOT NULL,
  cupo_aceptado_activo_senescyt varchar(50) NOT NULL,
  Tiene_Título_de_3er_nivel varchar(50) NOT NULL,
  Definición_de_Gratuidad varchar(100) NOT NULL,
  DEFINICIÓN_DE_APERTURA varchar(100) NOT NULL,
  ies_id int(11) NOT NULL,
  codigo_sniese varchar(20) NOT NULL,
  nombre_institucion varchar(200) NOT NULL,
  PRIMARY KEY (id_postulacion),
  FOREIGN KEY (ies_id) REFERENCES ies(ies_id),
  FOREIGN KEY (cedula) REFERENCES postulante(cedula),
  FOREIGN KEY (codigo_carrera) REFERENCES carrera(codigo_carrera)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabla de Postulación (Staging)
CREATE TABLE postulacion_stg (
  id_postulacion_stg int(11) NOT NULL AUTO_INCREMENT,
  cedula varchar(15) NOT NULL,
  tipo_documento varchar(50) NOT NULL,
  apellidos varchar(100) NOT NULL,
  nombres varchar(100) NOT NULL,
  nota_postula decimal(5,2) NOT NULL,
  fecha_nac date NOT NULL,
  nacionalidad varchar(50) NOT NULL,
  genero varchar(50) NOT NULL,
  provincia_reside varchar(100) NOT NULL,
  canton_reside varchar(100) NOT NULL,
  parroquia_reside varchar(100) NOT NULL,
  email varchar(100) default NULL,
  telefono varchar(20) NOT NULL,
  celular varchar(20) NOT NULL,
  etnia varchar(50) NOT NULL,
  discapacidad varchar(50) NOT NULL,
  codigo_carrera varchar(20) DEFAULT NULL,
  nombre_carrera varchar(200) NOT NULL,
  nivel varchar(50) NOT NULL,
  modalidad varchar(50) NOT NULL,
  jornada varchar(50) NOT NULL,
  area varchar(100) NOT NULL,
  subarea varchar(100) NOT NULL,
  grupo_asignacion varchar(50) NOT NULL,
  politica_cuotas varchar(100) NOT NULL,
  instancia_postulacion varchar(100) NOT NULL,
  instancia_asignacion varchar(100) NOT NULL,
  fecha_aceptacion date NOT NULL,
  cupo_aceptado_activo_senescyt varchar(50) NOT NULL,
  Tiene_Título_de_3er_nivel varchar(50) NOT NULL,
  Definición_de_Gratuidad varchar(100) NOT NULL,
  DEFINICIÓN_DE_APERTURA varchar(100) NOT NULL,
  ies_id int(200) NOT NULL,
  codigo_sniese varchar(20) NOT NULL,
  nombre_institucion varchar(200) NOT NULL,
  PRIMARY KEY (id_postulacion_stg)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;